from rasa_nlu.model import Interpreter

interpreter = Interpreter.load("./models/current/nlu")
