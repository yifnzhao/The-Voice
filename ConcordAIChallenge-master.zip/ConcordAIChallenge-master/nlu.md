## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:what
- Do you know the Basilica Notre Dame de Quebec?
- What is its architectural structure?

## intent:when
- When was the bell tower built?
- Is basilica Notre Dame de Quebec a Cathedral?
- What's its religious order?
- And what is it's status?
- What is the history of the Basilica Notre Dame de Quebec?
- Where is Basilica Notre Dame de Quebec located?

## intent:affirmative
- yes
- please
- sure
- of course

## intent:negative
- No
- Nope
- No, thanks
- That's okay
